<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


	<!--Eco Template Banner-->

		<div class="eco_banner banner-slider">
			<!--Eco Template Banner img-->
			<?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="item <?php echo e((($item->id)== 1) ? 'active':'notactive'); ?>">
					<figure>
						<img src="<?php echo e(Voyager::image($item->image)); ?>" alt=""/>
						<!--Eco Template Banner caption-->
						<div class="kode_eco_captions container position-center">
								<h2 data-animation="animated bounceInDown"><?php echo $item->getTranslatedAttribute('title1', app('lang')); ?> </h2>
								<br><br>
								<h1 data-animation="animated bounceInLeft"><?php echo $item->getTranslatedAttribute('title2', app('lang')); ?></h1>
								<p data-animation="animated bounceInRight"><?php echo $item->getTranslatedAttribute('paragraph', app('lang')); ?></p>

							<?php if($item->id==1): ?>
								<a href="aboutUs" class="btn-mediem"><?php echo e(trans('language.findOutMore')); ?> </a>
								<a href="contactUs" class="btn-mediem"><?php echo e(trans('language.getInvolved')); ?> </a>
							<?php endif; ?>

						</div>
					</figure>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			
			
		</div>
		<!--Eco Template Banner ends-->
			
		<!--Eco Template content-->
		<div class="content">
			<!--Eco Template section-->
			<section class="eco_services_environment aboutUs" style="
			padding:177px 60px;
		">
				<!--Eco Template section content-->
				<div class="container">
					<!--Eco Template Heading-->
					<div class="eco_headings">
						<h3><b><?php echo e(trans('language.breaf')); ?></b> <?php echo e(trans('language.history')); ?></h3>
						<span><i class="icon-nature-2"></i></span>
					</div>
					<!--Eco services-->
					<div class="eco_services">
						<div class="row">
							<div class="col-md-4 col-sm-6 col-xs-12">
								<div class="eco_items-services">
									<div class="eco_service_cols">
										<span><i class="fa fa-envelope-o  nat1"></i></span>
										<div>
											<h4><?php echo e(trans('language.Ourmessage')); ?> </h4>
											
											<p class="cutText3"><?php echo e(trans('language.OurMissionParagraph')); ?></p>
											<a href="openEcho3" style="color:#57c4c9"> <?php echo e(trans('language.readMore')); ?> </a>
										</div>
									</div>
									<div class="eco_service_cols">
										<span><i class="fa fa-history  nat1"></i></span>
										<div>
											<h4><?php echo e(trans('language.OurBreafHistory')); ?> </h4>
											<p class="cutText"><?php echo e(trans('language.OurBreafHistoryParagraph')); ?></p>
											<a href="openEcho" style="color:#57c4c9" data-toggle="modal" data-target="#historyModal"> <?php echo e(trans('language.readMore')); ?>   </a>
										</div>
									</div>
								</div>
							</div>
							<!--Eco Template section content center img-->
							<div class="col-md-4 col-sm-6 col-xs-12 hidden-sm-down">
								<figure class="text-center">
									<div class="thumb-widthout-layer">
										
										<p style="text-align:justify;margin-top:6px;margin-top:40px;font-size:17px;" class="introText">
												<?php echo trans('language.intro'); ?>

										</p>

									</div>
									
								</figure>
							</div>
							<div class="col-md-4 col-sm-6 col-xs-12">
								<div class="eco_items-services">
									<div class="eco_service_cols rtl_service">
										<span><i class="fa fa-eye nat1"></i></span>
										<div>
											<h4><?php echo e(trans('language.Ourvision')); ?></h4>
											<p class="cutText4"><?php echo e(trans('language.OurVisionParagraph')); ?></p>
										</div>
									</div>
									<div class="eco_service_cols rtl_service">
										<span><i class="fa fa-diamond nat1"></i></span>
										<div>
											<h4><?php echo e(trans('language.Ourgoals')); ?></h4>
											<p class="cutText2">
													<?php echo trans('language.OurGoalsParagraph'); ?>

											</p>
											<a href="openEcho2" style="color:#57c4c9" data-toggle="modal" data-target="#goalsModal"> <?php echo e(trans('language.readMore')); ?>  </a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--Eco Template section content ends-->
			</section>
			<!--Eco Template section ends-->

			<!--Eco Template section-->
			
			<hr>
			<!--Eco Template section ends-->

			<!-- Strategic Section -->
			
			<!-- Strategic Section End -->
			<!--Eco Template section-->
			<div class="eco_filing_form contactUs">
				<!--Eco donation form-->
				<div class="container">
					<div class="eco_donation_form">
						<div class="row">
							<div class="col-md-6 col-sm-6 responsive-col-xs contactForm">
								<div class="eco_form_importer">
									<!--Eco Template Heading-->
									<div class="eco_headings">
										<h3 class="contactHeading"><b><?php echo e(trans('language.contactUs')); ?></b></h3>
										<h6 class="contactHeading"><?php echo e(trans('language.contactUsSpan')); ?> </h6>
									</div>
									<!--Eco donation form-->

									<!--Eco input your detail-->
									<div class="eco_input_your_detail">
										<form method="POST" action="<?php echo e(url('contactUs')); ?>">
											<?php echo e(csrf_field()); ?>

											<div class="eco_importer"><input name="UserName" type="text" placeholder="<?php echo e(trans('language.name')); ?>" class="eco_input_types"></div>
											<div class="eco_importer"><input name="UserPhone" type="text" placeholder="<?php echo e(trans('language.emailOrPhone')); ?>" class="eco_input_types"></div>
											<div class="eco_importer">
												<textarea  name="UserMessage" placeholder="<?php echo e(trans('language.subject')); ?>" style="height:200px" class="form-control"></textarea>
											</div>
											<div class="form-submit-eco-btn">
												<button class="lg-button"><?php echo e(trans('language.send')); ?></button>
											</div>
										</form>
									</div>
									<!--Eco input your detail ends-->
								</div>
							</div>
							<div class="col-md-6 col-sm-6 responsive-col-xs">
								<!--Eco Process of count up-->
								<div class="eco_process_of_counter">
									<div>
										<h3 style="color:#fff !important">Contact Info here<h3>
									</div>
								</div>
								<!--Eco Process of count up ends-->
							</div>
						</div>
					</div>
				</div>
				<!--Eco container ends-->
			</div>
			<!--Eco donation form ends-->

			






			<!--Eco section start-->
			
			<!--Eco section ends-->

		</div>
		<!--Eco content ends-->
		<section class="activities acti">

				<div class="eco_headings">
						<h3 class="rightText"><b><?php echo e(trans('language.act')); ?></b></h3>
						<h6 class="rightText"><?php echo e(trans('language.actSpan')); ?></h6>
						<span><i class="icon-nature-2"></i></span>
				</div>

				
					
			
			<div style="text-align:center;padding-bottom:22px;">
					<button class="buttonCarousel buttonCarousel11 buttonHoverActive" data-target="#carouselExampleIndicators" data-slide-to="0" class="active"><?php echo e(trans('language.acti')); ?></button>
					<button class="buttonCarousel buttonCarousel12" data-target="#carouselExampleIndicators" data-slide-to="1"><?php echo e(trans('language.acti2')); ?></button>
					<button class="buttonCarousel buttonCarousel13" ><?php echo e(trans('language.acti3')); ?></button>
			</div>
			<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" data-interval="0" style="text-align:right">
				<div class="carousel-inner" style="    padding-bottom: 35px">
				  
	
					<div class="carousel-item active carouselBorder" dir="ltr">
						<div class="col-lg-2"></div>
						<div class="col-lg-6">
							<p class="carouselParagraph">
								
								<?php echo $ourWork[1]->getTranslatedAttribute('paragraph', app('lang')); ?>

							</p>
						</div>
						<div class="col-lg-4">
								
								<img class="d-block w-100 img-flude imageCarousel" src="<?php echo e(Voyager::image($ourWork[1]->image)); ?>" alt="First slide" >
						</div>
					</div>
					<div class="carousel-item  carouselBorder">
						<div class="col-lg-2"></div>
						<div class="col-lg-6">
							<p class="carouselParagraph">
								<?php echo $ourWork[0]->getTranslatedAttribute('paragraph', app('lang')); ?>

							</p>
						</div>
						<div class="col-lg-4">
								<img class="d-block w-100 img-flude imageCarousel" src="<?php echo e(Voyager::image($ourWork[0]->image)); ?>" alt="First slide" >
						</div>
					</div>
					<div class="carousel-item  carouselBorder">
						<div class="col-lg-2"></div>
						<div class="col-lg-6">
							<p class="carouselParagraph">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							</p>
						</div>
						<div class="col-lg-4">
								<img class="d-block w-100 img-flude imageCarousel" src="<?php echo e(asset('images/1.png')); ?>" alt="First slide" >
						</div>
					</div>
	
				</div>
				<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
				  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
				  <span class="sr-only">Previous</span>
				</a>
				<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
				  <span class="carousel-control-next-icon" aria-hidden="true"></span>
				  <span class="sr-only">Next</span>
				</a>
			</div>
		</section>
		
		<div class="clearfix"></div>
		
		<div class="location">
				<div class="eco_headings">
						<h3 class="rightText"><b><?php echo e(trans('language.find')); ?></b></h3>
						<h6 class="rightText"><?php echo e(trans('language.findSpan')); ?></h6>
						<span><i class="icon-nature-2"></i></span>
				</div>

				<div>
					<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15389.849176084062!2d44.2036602!3d15.3514296!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x34506c1d93ec2d2f!2sAl-Noman+Exchange+Co!5e0!3m2!1sen!2s!4v1559312386517!5m2!1sen!2s" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>	
				</div>
		</div>
		
		<!-- Modal -->
<div class="modal fade" id="goalsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
		  <div class="modal-content">
			<div class="modal-header">
			  <h5 class="modal-title" id="exampleModalLabel"><?php echo e(trans('language.Ourgoals')); ?></h5>
			  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			  </button>
			</div>
			<div class="modal-body">
					<?php echo trans('language.OurGoalsParagraph'); ?>

			</div>
			<div class="modal-footer">
			  <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(trans('language.exit')); ?></button>
			</div>
		  </div>
		</div>
</div>


<div class="modal fade" id="historyModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
		  <div class="modal-content">
			<div class="modal-header">
			  <h5 class="modal-title" id="exampleModalLabel"><?php echo e(trans('language.OurBreafHistory')); ?></h5>
			  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			  </button>
			</div>
			<div class="modal-body">
					<?php echo trans('language.OurBreafHistoryParagraph'); ?>

			</div>
			<div class="modal-footer">
			  <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(trans('language.exit')); ?></button>
			</div>
		  </div>
		</div>
</div>

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>