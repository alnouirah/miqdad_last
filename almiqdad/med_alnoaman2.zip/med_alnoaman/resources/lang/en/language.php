<?php

return [

    'home'=>'home',
    'aboutUs'=>'About us',
                'BreifHistory'=>'company profile',
                'missionAndVision'=>'mission and vision',
                'strategies'=>'strategies',
    'ourProduct'=>'our Product',
    'ourPartners'=>'our Partners',
    'ourClients'=>'our Clients',
    'contactUs'=>'contact Us',
    'goalsAndActivities'=>'Goals and activities',
    'messageUs'=>'message us',
    'findOutMore'=>'Find Out More',
    'getInvolved'=>'get Involved!',
    'breaf'=>'About',
    'history'=>'Us',
    'intro'=>'
                <b>AL-MIQDAD PHARMA </b> is a private Yemeni institution whose business activities depend on import, market and distribute the medicines and medical supplies (wholesale, retail).
    ',
    'ourProducts'=>'Our products',
    'ourProductsSpan'=>'Quailty , Imagenary , Respectfully',
    'goalsAndActivitiesSpan'=>'Live the Dream',
    'Act'=>'How we work !',
    'Goal'=>'Goals',
    'plan'=>'Plans',
    'contactUsSpan'=>'Dont worry Your info is transmated crepytedly and we will not share it with any one else .',
    'name'=>'name',
    'emailOrPhone'=>'Email or Phone',
    'subject'=>'Message',
    'send'=>'send',
    'defferentMed'=>'Drugs',
    'parteners'=>'Quality Partners',
    'happyCustomers'=>'Happy Customers',
    'benefitStatus'=>'People Benefits',
    'partners'=>'Partners',
    'partnersSpan'=>'Be with the Best !',
    'findMain'=>'Location',
    'findSpan'=>'our location ',
    'find'=>'just beside You !',
    'howWeWork'=>'how we wrok',
    'servicesAndActivities'=>'services and activities',
    'productAndPartners'=>'product and partners',
    'act'=>'How we work !',
    'actSpan'=>'Know more !',
    'acti'=>'activities',
    'acti2'=>'Strategic Markting Plan',
    'acti3'=>'products and partners',
    'readMore'=>'raed more ...',
    'Ourvision'=>'vision',
    'OurVisionParagraph'=>'We look to become one of the top ten agent and distributer and to be the most successful and respected in Yemeni market.',
    'Ourmessage'=>'Mission',
    'OurMissionParagraph'=>'We strive to achieve full customer care by providing high quality medical products and services that meet international standards and comply with local laws and regulations with good professional performance and reasonable prices.',
    'Ourgoals'=>'Goals',
    'OurGoalsParagraph'=>'
    
                            * Develop a specific business plan for our company that will guide the work of all managers and employees to achieve the ideal performance to reach the desired results to strengthen the bridge of trust between our customers and us. <br><br> 
                            
                            * Expand to all pharmaceutical products rang and cover all needs of healthcare practitioners, customers and patients as well as expand within the plans and market research and knowledge of the status of competition which is constantly updated. <br><br> 
                            
                            * Providing customers and patients with high quality medicines with acceptable economic value. <br><br> 
                            
                            * Implementing the most advanced and innovative management and marketing techniques. <br><br> 
                            
                            * Contribute to the improvement of market requirements while recognizing the continuous changes in the market.
                              Contribute to the improvement of market requirements while recognizing the continuous changes in the market. * <br><br> 
                              
                            * Our commitment to provide distinctive medical products and services which are expected by our customers and thus    contributing to increasing our market share. <br><br>
                            
                            * Continue development of our staff team and hire qualified employees in order to improve the quality of work and     access to excellence in customer service.',
    'OurBreafHistory'=>'History',
    'OurBreafHistoryParagraph'=>"
    
    Almiqdad Pharma is established to cater to the growing pharmaceutical market in Yemen and also to provide Agency services to new pharmaceutical companies that are keen to enter the Yemeni market.
    Our core business is to trade, import, marketing and distribution of pharmaceutical products, medical supplies and cosmetics to private pharmacies, hospitals, medical clinics, government centers and hospitals. In 2014, we started as a single pharmacy and then spread over time to become a group of pharmacies. Thanks to our expertise in this field and our strong potential, Almiqdad Pharma was established to represent our company (as an exclusive agent) of the world's leading manufacturers and suppliers of high quality healthcare products from different countries.
    The management is willingness to invest in this service reflects long term vision to make our Corporation as valuable business partners for healthcare companies interested in marketing their products in Republic of Yemen. Almiqdad Pharma employs and selects highly experienced medical representatives to market its company & products in Yemen as well as a number of other financial and customer service personnel.
    
    
    ",
    'OurBreafHistoryMiddle'=>'History',
    'exit'=>'close',
    'location'=>'45 round - Khawlan Street  ',
    'location2'=>'Sana’a, Republic Of Yemen ',
    'aboutFooter'=>'ABOUT AL-MIQDAD PHARM ',
    'phoneFooter'=>'00967 - 777734241 / 00967 - 713601877 ',
    'copyRights'=>'© Copyrights 2016 All rights reserved by: Almeqdad pharma',
    'logoFooter'=>'AL-MIQDAD PHARMA',
];
